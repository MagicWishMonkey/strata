

def debug(o):
    print "DEBUG!"