# # import os
# # import sys
# # import socket
# # from fuze.structs.enums import *
# #
# #
# # APP_PATH = os.getcwd()
# #
# #
# # IP_ADDRESS = None
# # try:
# #     IP_ADDRESS = socket.gethostbyname(socket.gethostname())
# # except:
# #     print "Unable to get the local ip address"
# #
# #
# # BASE_36_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
# # LETTERS = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
# # # LETTER_TABLE = dict((c, c) for c in LETTERS)
# # # for c in LETTERS:
# # #     LETTER_TABLE[c.lower()] = c.lower()
# #
# # NUMBERS = ["0","1","2","3","4","5","6","7","8","9"]
# # NUMBER_TABLE = dict((int(c), int(c)) for c in NUMBERS)
# # NUMBERS = NUMBER_TABLE.keys()
#
#
# NUMBERS = [0,1,2,3,4,5,6,7,8,9]
# LETTERS = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
# BASE_36_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
